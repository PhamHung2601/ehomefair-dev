<?php
if( ! defined( 'ABSPATH' ) ) {
    exit ; // Exit if accessed directly
}
?>
<div class="<?php echo SUMO_PP_PLUGIN_PREFIX . '-payment-not-found' ; ?> woocommerce-Message woocommerce-Message--info woocommerce-info">
    <p>
        <?php echo $message ; ?>
    </p>
</div>